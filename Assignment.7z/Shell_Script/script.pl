#!/usr/bin/perl
#**************************************************************************************************#
#Assignment             : Plivo_BasicCall_Automate
#Author                 : Ujwal Koteesh
#DATE OF AUTOMATION     : Dec-2020
#**************************************************************************************************#

use Net::SSH::Perl;
use POSIX;
use Exporter;
use Data::Dumper;

our $uas_IPV4 = "10.34.91.201"; # This address will be used as interface IP address for UAS after performing ssh to the same..
our $uac_IPV4 = "10.34.91.200"; # This address will be used as interface IP address for UAC after performing ssh to the same..
our $SIPPPATHBIN = '/usr/bin/sipp'; # This would be the output of "which sipp";
our $SIPPPATH = "/root/Ujwal/Plivo_Assignment/PerlScript";  # This is the path where XML sipp scripts are present 
our $uac_port = "5060";
our $uas_port = "5062";
our $domain = "phone.plivo.com";
our $UA_Passwd = "plivo";
our $calledNum = "test895187951711567647677";
our $callingNum = "test1281881673873471385";



# This section defines the Linux  Username and Password for the UAC and UAS sipp server.

my $uas_username = "root";
my $uas_pwd = "sonus1";
my $uac_username = "root";
my $uac_pwd = "sonus1";

#This is to set File Descriptors maximum values.

`echo 65535 > /proc/sys/fs/file-max`;

`ulimit -n unlimited`;


# SIPP command line variable definition section

my $UAC_Register_cmd = "$SIPPPATHBIN -sf $SIPPPATH/register.xml -s $callingNum  $domain -inf call.csv -m 1 -i $uac_IPV4 -p $uac_port -ap $UA_Passwd -trace_msg -auth_uri $callingNum";

my $UAC_Call_cmd = "$SIPPPATHBIN -sf $SIPPPATH/uac_call.xml -s $calledNum  $uas_IPV4 -inf call.csv -m 1 -i $uac_IPV4 -p $uac_port $domain  -ap $UA_Passwd -aa  -trace_msg -trace_logs -trace_stat";

my $UAS_Register_cmd = "$SIPPPATHBIN -sf $SIPPPATH/register.xml -s $calledNum $domain  -inf call.csv -m 1 -i $uas_IPV4 -p $uas_port -ap $UA_Passwd  -trace_msg -auth_uri $calledNum";

my $UAS_Call_cmd = "$SIPPPATHBIN -sf $SIPPPATH/uas.xml -i $uas_IPV4 -p $uas_port -aa -trace_msg -s $calledNum -inf call.csv -d 50s -m 3 -trace_logs -bg";

# Sipp is executed here

my $output = `$UAC_Register_cmd`;
print "$output";



#This section prints the sipp commands presented to sipp server.

print " UAS_Register = $UAS_Register_cmd\n";
print " UAC_Register = $UAC_Register_cmd\n";
print "UAS_Call = $UAS_Call_cmd\n";
print "UAC_Call = $UAC_Call_cmd\n";

# Implement SSH to UAC and UAS

print "Performing SSH to UAS\n";
our $ssh_uas = Net::SSH::Perl->new($uas_IPV4);
$ssh_uas->login($uas_username,$uas_pwd);

print "Performing SSH to UAC\n";
our $ssh_uac = Net::SSH::Perl->new($uac_IPV4);
$ssh_uac->login($uac_username,$uac_pwd);



# This is commented
#my $command_uas = "sipp -sf uas.xml -i 10.34.91.201 -p 23233 -m 1 -trace_logs -trace_msg -bg";
#my $command_uac = "sipp -sf uac.xml -i 10.34.91.200 -p 23231 -m 1 -s 5555  10.34.92.188 -trace_msg -trace_logs -trace_stat  ";


print "Executing Register command at UAS\n";
$ssh_uas->cmd("$UAS_Register_cmd");


sleep(2);


print "Executing UAS.xml command at UAS\n";
$ssh_uas->cmd("$UAS_Call_cmd");
sleep(2);


print "Executing Register command at UAC\n";
$ssh_uac->cmd("$UAC_Register_cmd");
sleep(2);

print "Executing sipp command at UAC\n";
my $output_uac = $ssh_uac->cmd("$UAS_Call_cmd");

sleep(60);



# This will open the most recent UAS log file
my $cmd = "ls -lrt /root/uas*logs.log|tail -1|awk \'{print \$NF}\'";
$logFileName_UAS =`$cmd`;
print "$logFileName_UAS";

# This will open the most recent UAC log file
$cmd = "ls -lrt /root/uac*logs.log|tail -1|awk \'{print \$NF}\'";
$logFileName_UAC =`$cmd`;
print "$logFileName_UAC";


# Open the File in Read mode:

open(DATA1, "<$logFileName_UAS") or die "Couldn't open file $logFileName_UAS, $!";
while(<DATA1>)
{
	print STDOUT $_;
}

open(DATA2, "<$logFileName_UAC") or die "Couldn't open file $logFileName_UAC, $!";
while(<DATA2>)
{
        print STDOUT $_;
}


$cmd = "ls -lrt /root/uac*.csv|tail -1|cut -d \" \" -f 9";
$output =`$cmd`;
print " Stats file is $output";

`chmod 777 *`;
# Test to extract fields from a csv file
my $file = $output or die;
my @words;
open(DATA, "<$file") or die "Couldn't open file, $!";
while (my $line = <DATA>)  
{ 
    chomp $line; 
    # Split the line and store in words array. I have used Delimeter as ; as .csv file had same by default. 
    @words = split ";", $line;   
}

#Fetching the Fixed array element  value containing response time duration.

print " call duration is $words[73]\n";


undef $ssh_uas;
undef $ssh_uac;
close(DATA1);
close(DATA2);
close(DATA);
